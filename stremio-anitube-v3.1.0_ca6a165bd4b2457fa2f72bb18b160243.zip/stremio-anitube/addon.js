'use strict';

const { addonBuilder } = require('stremio-addon-sdk');
const scraper = require('./src/scraper');
const { extractStreams } = require('./src/extractor');

const manifest = {
  id: 'community.anitube.news',
  version: '3.1.0',
  name: '🎌 AniTube.news (V3 Plus)',
  description: 'Addon v3.1: RESTAURADO botões Google Video + PROXY LOCAL FHD (HLS). Integrado com AniTube.news.',
  logo: 'https://www.anitube.news/wp-content/uploads/logo-anitube-2.png',
  background: 'https://www.anitube.news/wp-content/themes/anitube/img/bg.jpg',
  resources: ['catalog', 'meta', 'stream'],
  types: ['series', 'anime'],
  idPrefixes: ['anitube:'],
  catalogs: [
    {
      id: 'anitube_ultimos_eps',
      type: 'series',
      name: '🆕 AniTube – Últimos Episódios',
    },
    {
      id: 'anitube_mais_vistos',
      type: 'series',
      name: '🔥 AniTube – Mais Vistos',
    },
    {
      id: 'anitube_recentes',
      type: 'series',
      name: '📺 AniTube – Animes Recentes',
    },
    {
      id: 'anitube_lista',
      type: 'series',
      name: '📚 AniTube – Lista Completa',
      extra: [
        { name: 'skip', isRequired: false },
        { name: 'search', isRequired: false }
      ]
    },
  ],
};

const builder = new addonBuilder(manifest);

// ───────────────────────────────────────────────────────────────────────────
// CATALOG HANDLER
// ───────────────────────────────────────────────────────────────────────────
builder.defineCatalogHandler(async ({ id, extra }) => {
  const page = Math.floor((extra.skip || 0) / 20) + 1;

  try {
    if (extra.search) {
      return { metas: await scraper.searchAnimes(extra.search, page) };
    }

    switch (id) {
      case 'anitube_ultimos_eps':
        return { metas: await scraper.getLatestEpisodes() };
      
      case 'anitube_mais_vistos':
        return { metas: await scraper.getMostWatched() };
      
      case 'anitube_recentes':
        return { metas: await scraper.getRecentAnimes() };
      
      case 'anitube_lista':
      default:
        return { metas: await scraper.getAnimeList(page) };
    }
  } catch (e) {
    console.error(`[Catalog] Erro: ${e.message}`);
    return { metas: [] };
  }
});

// ───────────────────────────────────────────────────────────────────────────
// META HANDLER
// ───────────────────────────────────────────────────────────────────────────
builder.defineMetaHandler(async ({ id }) => {
  const animeId = id.replace('anitube:', '');
  try {
    return await scraper.getAnimeMeta(animeId);
  } catch (e) {
    console.error(`[Meta] Erro: ${e.message}`);
    return { meta: {} };
  }
});

// ───────────────────────────────────────────────────────────────────────────
// STREAM HANDLER
// ───────────────────────────────────────────────────────────────────────────
builder.defineStreamHandler(async ({ id }) => {
  const epId = id.replace('anitube:', '');
  try {
    const { sources, episodeUrl } = await scraper.getEpisodeIframes(epId);
    if (!sources || sources.length === 0) return { streams: [] };

    const streams = await extractStreams(sources, episodeUrl);
    return { streams };
  } catch (e) {
    console.error(`[Stream] Erro: ${e.message}`);
    return { streams: [] };
  }
});

module.exports = builder.getInterface();
