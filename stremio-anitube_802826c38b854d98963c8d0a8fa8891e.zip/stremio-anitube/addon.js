/**
 * addon.js — Addon Stremio para AniTube.news
 *
 * Recursos:
 *  - catalog: lista de animes recentes + lista completa + busca
 *  - meta: informações detalhadas do anime com lista de episódios
 *  - stream: streams reais de vídeo via googlevideo.com (via Blogger API)
 */

const { addonBuilder, serveHTTP } = require('stremio-addon-sdk');
const scraper = require('./scraper');

// ─── Manifest ────────────────────────────────────────────────────────────────

const manifest = {
  id: 'community.anitube.news',
  version: '1.0.0',
  name: 'AniTube.news',
  description:
    'Assista animes legendados e dublados em português do AniTube.news diretamente no Stremio.',
  logo: 'https://www.anitube.news/wp-content/themes/newanitubevelho/img/logo.png',
  background:
    'https://www.anitube.news/wp-content/uploads/assistir-jujutsu-kaisen-3-todos-os-episodios-todos-os-episodios-online-anitube.jpg',
  resources: ['catalog', 'meta', 'stream'],
  types: ['series'],
  idPrefixes: ['anitube_'],
  catalogs: [
    {
      type: 'series',
      id: 'anitube_recentes',
      name: 'AniTube – Recentes',
      extra: [{ name: 'search', isRequired: false }],
    },
    {
      type: 'series',
      id: 'anitube_lista',
      name: 'AniTube – Lista Completa',
      extra: [
        { name: 'search', isRequired: false },
        { name: 'skip', isRequired: false },
      ],
    },
  ],
  behaviorHints: {
    adult: false,
    p2p: false,
  },
};

// ─── Builder ─────────────────────────────────────────────────────────────────

const builder = new addonBuilder(manifest);

// ─── Cache em memória ────────────────────────────────────────────────────────

const cache = new Map();
const CACHE_TTL_CATALOG = 10 * 60 * 1000;  // 10 min para catálogos
const CACHE_TTL_META    = 30 * 60 * 1000;  // 30 min para meta
const CACHE_TTL_STREAM  =  5 * 60 * 1000;  // 5 min para streams (URLs expiram)

function cacheGet(key) {
  const item = cache.get(key);
  if (!item) return null;
  if (Date.now() - item.ts > item.ttl) {
    cache.delete(key);
    return null;
  }
  return item.value;
}

function cacheSet(key, value, ttl = CACHE_TTL_CATALOG) {
  cache.set(key, { value, ts: Date.now(), ttl });
}

// ─── Helper: converter anime para MetaPreview ────────────────────────────────

function toMetaPreview(anime) {
  return {
    id: anime.id,
    type: 'series',
    name: anime.title,
    poster: anime.poster || undefined,
    posterShape: 'poster',
    background: anime.poster || undefined,
  };
}

// ─── Catalog Handler ──────────────────────────────────────────────────────────

builder.defineCatalogHandler(async ({ type, id, extra }) => {
  if (type !== 'series') return { metas: [] };

  const search = extra && extra.search;
  const skip = extra && extra.skip ? parseInt(extra.skip, 10) : 0;
  const PAGE_SIZE = 30;
  const page = Math.floor(skip / PAGE_SIZE) + 1;

  // ── Busca ──
  if (search) {
    const cacheKey = `search_${search.toLowerCase()}`;
    let metas = cacheGet(cacheKey);

    if (!metas) {
      try {
        console.log(`[catalog] Buscando: "${search}"`);
        const raw = await scraper.searchAnimes(search);
        metas = raw.map(toMetaPreview);
        cacheSet(cacheKey, metas, CACHE_TTL_CATALOG);
      } catch (e) {
        console.error('[catalog] search error:', e.message);
        return { metas: [] };
      }
    }
    return { metas };
  }

  // ── Recentes ──
  if (id === 'anitube_recentes') {
    const cacheKey = 'recentes';
    let metas = cacheGet(cacheKey);

    if (!metas) {
      try {
        console.log('[catalog] Buscando recentes...');
        const raw = await scraper.getRecentAnimes();
        metas = raw.map(toMetaPreview);
        cacheSet(cacheKey, metas, CACHE_TTL_CATALOG);
      } catch (e) {
        console.error('[catalog] recentes error:', e.message);
        return { metas: [] };
      }
    }
    return { metas };
  }

  // ── Lista Completa ──
  if (id === 'anitube_lista') {
    const cacheKey = `lista_page_${page}`;
    let metas = cacheGet(cacheKey);

    if (!metas) {
      try {
        console.log(`[catalog] Lista completa página ${page}...`);
        const raw = await scraper.getAnimeList(page);
        metas = raw.map(toMetaPreview);
        cacheSet(cacheKey, metas, CACHE_TTL_CATALOG);
      } catch (e) {
        console.error('[catalog] lista error:', e.message);
        return { metas: [] };
      }
    }
    return { metas };
  }

  return { metas: [] };
});

// ─── Meta Handler ─────────────────────────────────────────────────────────────

builder.defineMetaHandler(async ({ type, id }) => {
  if (type !== 'series') return { meta: null };
  if (!id.startsWith('anitube_')) return { meta: null };

  // ID formato: anitube_{anitubeId}
  // Não processar IDs de episódios (anitube_ep_...)
  if (id.startsWith('anitube_ep_')) return { meta: null };

  const anitubeId = id.replace('anitube_', '');
  const cacheKey = `meta_${anitubeId}`;
  let meta = cacheGet(cacheKey);

  if (!meta) {
    try {
      console.log(`[meta] Buscando detalhes de anime ID ${anitubeId}...`);
      const details = await scraper.getAnimeDetails(anitubeId);

      // Converter episódios para o formato Stremio
      const videos = details.episodes.map((ep, idx) => {
        const epNumMatch =
          ep.title.match(/epis[oó]dio\s+0*(\d+)/i) ||
          ep.title.match(/\s+0*(\d+)\s*$/);
        const epNum = epNumMatch ? parseInt(epNumMatch[1], 10) : idx + 1;

        return {
          id: ep.id,      // anitube_ep_{epId}
          title: ep.title,
          season: 1,
          episode: epNum,
          released: new Date(0).toISOString(),
        };
      });

      meta = {
        id: details.id,
        type: 'series',
        name: details.title,
        poster: details.poster || undefined,
        posterShape: 'poster',
        background: details.poster || undefined,
        description: details.description,
        genres: details.genres,
        releaseInfo: details.year ? String(details.year) : undefined,
        website: `https://www.anitube.news/video/${anitubeId}/`,
        videos,
      };

      cacheSet(cacheKey, meta, CACHE_TTL_META);
    } catch (e) {
      console.error('[meta] error:', e.message);
      return { meta: null };
    }
  }

  return { meta };
});

// ─── Stream Handler ───────────────────────────────────────────────────────────

builder.defineStreamHandler(async ({ type, id }) => {
  if (type !== 'series') return { streams: [] };

  // ID do stream para séries: "{videoId}:{season}:{episode}"
  // nosso videoId é: anitube_ep_{epAnitubeId}
  const parts = id.split(':');
  const videoId = parts[0]; // ex: anitube_ep_923964

  if (!videoId.startsWith('anitube_ep_')) {
    console.log('[stream] ID inválido (não é anitube_ep_):', id);
    return { streams: [] };
  }

  const epAnitubeId = videoId.replace('anitube_ep_', '');
  const cacheKey = `stream_${epAnitubeId}`;
  let streams = cacheGet(cacheKey);

  if (!streams) {
    try {
      console.log(`[stream] Resolvendo streams do episódio ID ${epAnitubeId}...`);
      streams = await scraper.getEpisodeStreams(epAnitubeId);
      cacheSet(cacheKey, streams, CACHE_TTL_STREAM);
    } catch (e) {
      console.error('[stream] error:', e.message);
      streams = [
        {
          externalUrl: `https://www.anitube.news/video/${epAnitubeId}/`,
          title: '🌐 Abrir no AniTube',
        },
      ];
    }
  }

  return { streams };
});

// ─── Iniciar servidor ─────────────────────────────────────────────────────────

const PORT = process.env.PORT || 7000;
serveHTTP(builder.getInterface(), { port: PORT });

console.log('\n╔════════════════════════════════════════════════╗');
console.log('║        🎌 AniTube Stremio Addon                ║');
console.log('╠════════════════════════════════════════════════╣');
console.log(`║  Manifest: http://127.0.0.1:${PORT}/manifest.json  ║`);
console.log(`║  Instalar: stremio://127.0.0.1:${PORT}/manifest.json║`);
console.log('╚════════════════════════════════════════════════╝\n');
