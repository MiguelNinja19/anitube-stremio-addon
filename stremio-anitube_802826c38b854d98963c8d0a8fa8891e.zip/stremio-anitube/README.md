# 🎌 AniTube Stremio Addon

Addon para o **Stremio** que traz todo o catálogo do [AniTube.news](https://www.anitube.news) — animes legendados e dublados em **português** — diretamente para o seu player.

## ✨ Funcionalidades

- 📋 **Catálogo completo** de animes (legendados e dublados)
- 🔍 **Busca** por nome de anime
- 📺 **Streams de vídeo reais** em 720p e 360p (via Google Video)
- 🔄 **Cache** para reduzir requisições ao site

## 🚀 Como rodar

### Pré-requisitos

- [Node.js](https://nodejs.org/) 16+
- npm

### Instalação

```bash
git clone <repo>
cd stremio-anitube
npm install
npm start
```

O addon estará disponível em `http://127.0.0.1:7000`

### Instalar no Stremio

1. Abra o Stremio
2. Vá em **Addons → Community Addons**
3. Clique em **Add Addon** e cole:
   ```
   http://127.0.0.1:7000/manifest.json
   ```
   ou use o link mágico:
   ```
   stremio://127.0.0.1:7000/manifest.json
   ```

## 🏗️ Estrutura

```
stremio-anitube/
├── addon.js      # Servidor principal do addon (handlers do Stremio)
├── scraper.js    # Lógica de scraping do AniTube.news
├── package.json
└── README.md
```

## 🔧 Como funciona o stream

O addon segue o seguinte fluxo para obter as URLs de vídeo reais:

```
1. Página do episódio (/video/{id}/)
   ↓
2. iframe com token → www.anitube.news/{TOKEN}/0/0/bg.mp4
   ↓ (302 redirect)
3. api.anivideo.net/file/{LONG_TOKEN}/1/{TITLE}
   → HTML com iframe do Blogger
   ↓
4. API do Blogger (batchexecute)
   → URLs diretas do googlevideo.com (720p, 360p)
```

## 🌐 Deploy (opcional)

Para uso público, faça deploy em serviços como:
- [Render](https://render.com) (gratuito)
- [Railway](https://railway.app) (gratuito)
- [Fly.io](https://fly.io)

Configure a variável `PORT` conforme necessário.

## ⚠️ Aviso

Este addon é para uso pessoal. O AniTube.news não hospeda vídeos — os streams vêm de serviços externos (Blogger/Google Video). Respeite os direitos autorais.
