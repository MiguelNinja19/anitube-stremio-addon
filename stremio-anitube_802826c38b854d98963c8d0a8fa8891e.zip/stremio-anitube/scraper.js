/**
 * scraper.js — Funções de scraping do anitube.news
 *
 * Fluxo de stream:
 *  1. Página do episódio (/video/{epId}/)
 *     → contém iframe src: https://www.anitube.news/{TOKEN}=/0/0/bg.mp4?p=1&q={BASE64_TITLE}
 *  2. O iframe faz 302 redirect para:
 *     https://api.anivideo.net/file/{LONG_TOKEN}/1/{BASE64_TITLE}
 *  3. Essa página HTML contém um iframe do Blogger:
 *     https://www.blogger.com/video.g?token={BLOGGER_TOKEN}&origin=...
 *  4. A API do Blogger retorna as URLs reais de vídeo (googlevideo.com):
 *     https://rr*.googlevideo.com/videoplayback?...
 */

const axios = require('axios');
const cheerio = require('cheerio');

const BASE_URL = 'https://www.anitube.news';

const HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
  Accept:
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
  Referer: 'https://www.anitube.news/',
};

/** Fetch com retry */
async function fetchPage(url, extraHeaders = {}, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      const resp = await axios.get(url, {
        headers: { ...HEADERS, ...extraHeaders },
        timeout: 15000,
        maxRedirects: 10,
      });
      return resp.data;
    } catch (err) {
      if (i === retries - 1) throw err;
      await new Promise((r) => setTimeout(r, 1000 * (i + 1)));
    }
  }
}

/** Fetch sem seguir redirects (retorna resp completa) */
async function fetchNoRedirect(url, extraHeaders = {}) {
  return axios.get(url, {
    headers: { ...HEADERS, ...extraHeaders },
    timeout: 10000,
    maxRedirects: 0,
    validateStatus: () => true,
  });
}

// ─── Catálogo ───────────────────────────────────────────────────────────────

/**
 * Lista de animes de uma página específica
 */
async function getAnimeList(page = 1) {
  const url =
    page === 1
      ? `${BASE_URL}/lista-de-animes-online/`
      : `${BASE_URL}/lista-de-animes-online/page/${page}/`;

  const html = await fetchPage(url);
  const $ = cheerio.load(html);
  const animes = [];

  $('a[href*="/video/"]').each((_, el) => {
    const href = $(el).attr('href');
    const title = $(el).attr('title') || $(el).text().trim();
    const img = $(el).find('img').first();
    const poster = img.attr('src') || img.attr('data-src') || null;

    if (!href || !title) return;

    const idMatch = href.match(/\/video\/(\d+)\//);
    if (!idMatch) return;

    const id = idMatch[1];
    const cleanTitle = title
      .replace(/\s*[–\-]\s*(todos os epis[oó]dios|all episodes)/gi, '')
      .trim();

    if (cleanTitle.length < 2) return;

    animes.push({
      id: `anitube_${id}`,
      title: cleanTitle,
      poster,
      anitubeId: id,
    });
  });

  return dedupe(animes, 'id');
}

/**
 * Busca animes por query
 */
async function searchAnimes(query) {
  const url = `${BASE_URL}/?s=${encodeURIComponent(query)}`;
  const html = await fetchPage(url);
  const $ = cheerio.load(html);
  const animes = [];

  $('a[href*="/video/"]').each((_, el) => {
    const href = $(el).attr('href');
    const title = $(el).attr('title') || $(el).text().trim();
    const img = $(el).find('img').first();
    const poster = img.attr('src') || img.attr('data-src') || null;

    if (!href || !title || title.length < 2) return;

    const idMatch = href.match(/\/video\/(\d+)\//);
    if (!idMatch) return;

    const cleanTitle = title
      .replace(/\s*[–\-]\s*(todos os epis[oó]dios|all episodes)/gi, '')
      .trim();

    animes.push({
      id: `anitube_${idMatch[1]}`,
      title: cleanTitle,
      poster,
      anitubeId: idMatch[1],
    });
  });

  return dedupe(animes, 'id');
}

/**
 * Animes recentes da home
 */
async function getRecentAnimes() {
  const html = await fetchPage(BASE_URL);
  const $ = cheerio.load(html);
  const animes = [];

  $('a[href*="/video/"]').each((_, el) => {
    const href = $(el).attr('href');
    const title = $(el).attr('title') || $(el).text().trim();
    const img = $(el).find('img').first();
    const poster = img.attr('src') || img.attr('data-src') || null;

    if (!href || !title || title.length < 2) return;

    const idMatch = href.match(/\/video\/(\d+)\//);
    if (!idMatch) return;

    const cleanTitle = title
      .replace(/\s*[–\-]\s*(todos os epis[oó]dios|all episodes)/gi, '')
      .trim();

    animes.push({
      id: `anitube_${idMatch[1]}`,
      title: cleanTitle,
      poster,
      anitubeId: idMatch[1],
    });
  });

  return dedupe(animes, 'id').slice(0, 50);
}

// ─── Meta ────────────────────────────────────────────────────────────────────

/**
 * Detalhes de um anime (página principal /video/{anitubeId}/)
 */
async function getAnimeDetails(anitubeId) {
  const url = `${BASE_URL}/video/${anitubeId}/`;
  const html = await fetchPage(url);
  const $ = cheerio.load(html);

  const title = $('h1')
    .first()
    .text()
    .replace(/\s*[–\-]\s*(todos os epis[oó]dios|all episodes)/gi, '')
    .trim();

  // Poster principal
  let poster = null;
  $('img').each((_, el) => {
    const src = $(el).attr('src');
    if (src && src.includes('wp-content/uploads') && !poster) {
      const w = parseInt($(el).attr('width') || '200', 10);
      if (w >= 50) poster = src;
    }
  });

  // Metadados do bloco .right
  const rightText = $('div.right').text();
  const genres = extractMeta(rightText, 'Gênero');
  const year = extractMeta(rightText, 'Ano');
  const studio = extractMeta(rightText, 'Estúdio');
  const tipo = extractMeta(rightText, 'Tipo de Episódio');

  // Sinopse
  let description = '';
  $('p').each((_, el) => {
    const txt = $(el).text().trim();
    if (txt.length > 80 && !txt.includes('Salvar meus dados') && !description) {
      description = txt;
    }
  });

  // Episódios
  const episodes = [];
  const seen = new Set();

  $('a[href*="/video/"]').each((_, el) => {
    const href = $(el).attr('href');
    const epTitle = $(el).text().trim();

    if (!href || href.includes('#')) return;
    if (href === url || href === `${BASE_URL}/video/${anitubeId}`) return;

    const idMatch = href.match(/\/video\/(\d+)\//);
    if (!idMatch) return;

    const epId = idMatch[1];
    if (seen.has(epId)) return;
    seen.add(epId);

    if (epTitle.length > 2) {
      episodes.push({
        id: `anitube_ep_${epId}`,
        anitubeEpId: epId,
        title: epTitle,
        url: href,
      });
    }
  });

  return {
    id: `anitube_${anitubeId}`,
    anitubeId,
    title,
    poster,
    description: description || `Assista ${title} online no AniTube`,
    genres: genres ? genres.split(',').map((g) => g.trim()) : [],
    year: year ? parseInt(year, 10) : null,
    studio,
    tipo,
    episodes,
  };
}

function extractMeta(text, key) {
  const regex = new RegExp(`${key}:\\s*([^\\n]+)`);
  const match = text.match(regex);
  return match ? match[1].trim() : null;
}

// ─── Stream ──────────────────────────────────────────────────────────────────

/**
 * Resolve os streams de um episódio.
 *
 * Fluxo:
 *   1. Pega HTML da página do episódio → extrai iframe.src (token do anitube)
 *   2. Faz 302 para api.anivideo.net → extrai iframe do Blogger
 *   3. Chama API do Blogger (_/BloggerVideoPlayerUi/data/batchexecute)
 *      → retorna URLs do googlevideo.com
 *
 * @param {string} epAnitubeId  ID numérico do episódio no anitube
 * @returns {Array} streams compatíveis com o Stremio
 */
async function getEpisodeStreams(epAnitubeId) {
  const pageUrl = `${BASE_URL}/video/${epAnitubeId}/`;

  // ── Passo 1: página do episódio ──
  const html = await fetchPage(pageUrl);
  const $ep = cheerio.load(html);

  const anitubeSrc = $ep('iframe.metaframe').first().attr('src');
  if (!anitubeSrc) {
    console.log('[stream] Nenhum iframe.metaframe encontrado em', pageUrl);
    return [{ externalUrl: pageUrl, title: '🌐 Abrir no AniTube' }];
  }

  // ── Passo 2: seguir redirect para api.anivideo.net ──
  let anivideoHtml;
  try {
    const r1 = await fetchNoRedirect(anitubeSrc, { Referer: pageUrl });
    const anivideoUrl = r1.headers['location'];
    if (!anivideoUrl) {
      // Às vezes não redireciona, tenta usar o body
      anivideoHtml = typeof r1.data === 'string' ? r1.data : null;
    } else {
      anivideoHtml = await fetchPage(anivideoUrl, { Referer: anitubeSrc });
    }
  } catch (e) {
    console.error('[stream] Erro ao seguir redirect anivideo:', e.message);
    return [{ externalUrl: pageUrl, title: '🌐 Abrir no AniTube' }];
  }

  if (!anivideoHtml) {
    return [{ externalUrl: pageUrl, title: '🌐 Abrir no AniTube' }];
  }

  // ── Passo 3: extrair token do Blogger ──
  const $av = cheerio.load(anivideoHtml);
  const bloggerSrc = $av('iframe.metaframe, iframe[src*="blogger.com"]').first().attr('src');

  if (!bloggerSrc) {
    console.log('[stream] Nenhum iframe do Blogger encontrado');
    return [{ externalUrl: pageUrl, title: '🌐 Abrir no AniTube' }];
  }

  const bloggerTokenMatch = bloggerSrc.match(/[?&]token=([^&]+)/);
  if (!bloggerTokenMatch) {
    console.log('[stream] Token do Blogger não encontrado em:', bloggerSrc);
    return [{ externalUrl: pageUrl, title: '🌐 Abrir no AniTube' }];
  }

  const bloggerToken = decodeURIComponent(bloggerTokenMatch[1]);

  // ── Passo 4: chamar API do Blogger ──
  const streams = await fetchBloggerStreams(bloggerToken, pageUrl);

  if (streams.length > 0) return streams;

  // Fallback: link externo
  return [{ externalUrl: pageUrl, title: '🌐 Abrir no AniTube' }];
}

/**
 * Busca URLs de vídeo via API interna do Blogger
 * @param {string} token  token do Blogger (do iframe src)
 * @param {string} referer  URL de referência
 * @returns {Array} streams Stremio
 */
async function fetchBloggerStreams(token, referer) {
  try {
    const batchUrl =
      'https://www.blogger.com/_/BloggerVideoPlayerUi/data/batchexecute?' +
      'rpcids=WcwnYd&source-path=%2Fvideo.g';

    const fReq = JSON.stringify([
      [['WcwnYd', JSON.stringify([token]), null, 'generic']],
    ]);

    const resp = await axios.post(
      batchUrl,
      'f.req=' + encodeURIComponent(fReq),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
          'User-Agent': HEADERS['User-Agent'],
          Referer: 'https://www.blogger.com/video.g',
          Origin: 'https://www.blogger.com',
        },
        timeout: 10000,
        validateStatus: () => true,
      }
    );

    const body = typeof resp.data === 'string' ? resp.data : JSON.stringify(resp.data);

    // O formato de resposta do Blogger é:
    // )]}'\n[["wrb.fr","WcwnYd","<inner json string>",...]]
    // O inner json string contém os dados de vídeo já sem escapes
    let videoEntries = [];

    try {
      const jsonStart = body.indexOf('[[');
      if (jsonStart !== -1) {
        const arr = JSON.parse(body.substring(jsonStart));
        // arr[0][2] é a string JSON interna com as URLs
        if (arr && arr[0] && arr[0][2]) {
          const inner = JSON.parse(arr[0][2]);
          // inner = [1, null, [[url, [itag]], [url, [itag]], ...]]
          if (inner && inner[2] && Array.isArray(inner[2])) {
            videoEntries = inner[2];
          }
        }
      }
    } catch (parseErr) {
      console.error('[blogger] Erro ao parsear resposta:', parseErr.message);
      // Fallback: regex nas URLs
      const rawMatches = [...body.matchAll(/"(https:\/\/[^"\\]*googlevideo[^"\\]*)"/g)];
      videoEntries = rawMatches.map((m) => [
        m[1].replace(/\\u003d/g, '=').replace(/\\u0026/g, '&'),
        [0],
      ]);
    }

    if (videoEntries.length === 0) return [];

    // Identificar qualidades pelas itags
    // itag=22 → 720p MP4, itag=18 → 360p MP4
    const itagMap = { 22: '720p', 18: '360p', 37: '1080p', 34: '360p', 35: '480p' };
    const streams = [];
    const seen = new Set();

    for (const entry of videoEntries) {
      const url = entry[0];
      const itags = entry[1] || [];
      const itag = itags[0] || 0;

      if (!url || seen.has(url)) continue;
      seen.add(url);

      const quality = itagMap[itag] || `Q${itag}`;
      streams.push({
        url,
        title: `▶ AniTube ${quality}`,
        behaviorHints: {
          notWebReady: false,
          bingeGroup: 'anitube',
        },
      });
    }

    // Ordenar: 1080p → 720p → resto
    const qualityOrder = { '1080p': 0, '720p': 1, '480p': 2, '360p': 3 };
    streams.sort((a, b) => {
      const qa = qualityOrder[a.title.split(' ').pop()] ?? 9;
      const qb = qualityOrder[b.title.split(' ').pop()] ?? 9;
      return qa - qb;
    });

    return streams;
  } catch (e) {
    console.error('[blogger] Erro:', e.message);
    return [];
  }
}

// ─── Utilitários ─────────────────────────────────────────────────────────────

function dedupe(arr, key) {
  const seen = new Set();
  return arr.filter((item) => {
    if (seen.has(item[key])) return false;
    seen.add(item[key]);
    return true;
  });
}

module.exports = {
  getAnimeList,
  searchAnimes,
  getRecentAnimes,
  getAnimeDetails,
  getEpisodeStreams,
};
