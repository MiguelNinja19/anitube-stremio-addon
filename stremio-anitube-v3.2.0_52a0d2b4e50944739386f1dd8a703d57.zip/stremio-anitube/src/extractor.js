'use strict';

/**
 * Extrator de streams - v3.2.0 (Merge v2.1.1 + v3.0.0)
 */

const fetch = require('node-fetch');

const UA_MOBILE = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36';

const ITAG_QUALITY = {
  '18': '360p',
  '22': '720p',
  '37': '1080p',
};

const PORT = parseInt(process.env.PORT || '7000', 10);

async function safeFetch(url, options = {}, timeout = 10000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, { ...options, signal: ctrl.signal });
    return res;
  } catch (e) {
    console.error(`[Extractor] Erro fetch ${url}: ${e.message}`);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/** Extrai a URL do m3u8 de um iframe videohls.php */
function extractHLSFromVideoHLS(iframeSrc) {
  if (!iframeSrc || !iframeSrc.includes('videohls.php')) return null;
  try {
    const urlObj = new URL(iframeSrc.startsWith('//') ? 'https:' + iframeSrc : iframeSrc);
    const d = urlObj.searchParams.get('d');
    if (d) return decodeURIComponent(d);
  } catch (e) {
    return null;
  }
  return null;
}

async function extractStreams(sources, episodeUrl) {
  const streams = [];

  for (const source of sources) {
    const { name, iframeSrc } = source;
    if (!iframeSrc) continue;

    const fullIframeSrc = iframeSrc.startsWith('//') ? 'https:' + iframeSrc : iframeSrc;

    // 1. Caso HLS (FHD) - Lógica do Proxy Local (v3.0.0)
    const hlsUrl = extractHLSFromVideoHLS(fullIframeSrc);
    if (hlsUrl) {
      const proxyUrl = `http://127.0.0.1:${PORT}/proxy/m3u8?url=${encodeURIComponent(hlsUrl)}&referer=${encodeURIComponent('https://www.anitube.news/')}`;
      
      streams.push({
        name: `🎌 AniTube | ${name}`,
        description: `[FHD] HLS Stream (Via Proxy Local)`,
        url: proxyUrl,
        behaviorHints: { notWebReady: true }
      });
      // Importante: No AniTube, o player FHD às vezes é só HLS, mas vamos tentar extrair outras fontes também
    }

    // 2. Caso Google Video (Blogger) - Lógica da v2.1.1
    // Tenta extrair de qualquer iframe que pareça ser um player ou proxy
    if (fullIframeSrc.includes('anitube.news') || fullIframeSrc.includes('api.anivideo.net') || fullIframeSrc.includes('blogger.com')) {
      try {
        const gvStreams = await extractFromProxyIframe(fullIframeSrc, episodeUrl);
        if (gvStreams && gvStreams.length > 0) {
          gvStreams.forEach(s => {
            streams.push({
              name: `🎌 AniTube | ${name}`,
              description: `[${s.quality}] GoogleVideo`,
              url: s.url,
              behaviorHints: {
                proxyHeaders: {
                  request: { 'User-Agent': UA_MOBILE }
                }
              }
            });
          });
        }
      } catch (e) {
        console.error(`[Extractor] Falha GoogleVideo em ${name}: ${e.message}`);
      }
    }
  }

  return streams;
}

async function extractFromProxyIframe(iframeSrc, referer) {
  const res = await safeFetch(iframeSrc, {
    headers: { 'User-Agent': UA_MOBILE, 'Referer': referer }
  });
  if (!res) return [];
  const html = await res.text();

  // Regex da v2.1.1
  const bloggerMatch = html.match(/src=["'](https:\/\/www\.blogger\.com\/video\.g\?token=[^"']+)["']/);
  if (bloggerMatch) {
    return await fetchBloggerStreams(bloggerMatch[1], iframeSrc);
  }
  return [];
}

async function fetchBloggerStreams(bloggerUrl, referer) {
  const tokenMatch = bloggerUrl.match(/token=([a-zA-Z0-9_\-]+)/);
  if (!tokenMatch) return [];
  const token = tokenMatch[1];

  // Corpo da v2.1.1
  const body = `f.req=%5B%5B%5B%22WcwnYd%22%2C%22%5B%5C%22${token}%5C%22%5D%22%2Cnull%2C%22generic%22%5D%5D%5D&`;
  
  const res = await safeFetch('https://www.blogger.com/_/BloggerVideoPlayerUi/data/batchexecute?rpcids=WcwnYd&bl=boq_bloggeruiserver_20260317.01_p0', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'User-Agent': UA_MOBILE,
      'Referer': bloggerUrl,
      'X-Same-Domain': '1'
    },
    body
  });

  if (!res) return [];
  const text = await res.text();
  return parseGoogleVideoUrls(text);
}

function parseGoogleVideoUrls(text) {
  const streams = [];
  const matches = text.matchAll(/https:\\\/\\\/[^\s]+?googlevideo\.com\\\/videoplayback[^\s]+?(?=\\")/g);
  const seenUrls = new Set();

  for (const m of matches) {
    let url = m[0].replace(/\\u003d/g, '=').replace(/\\u0026/g, '&').replace(/\\/g, '');
    if (seenUrls.has(url)) continue;
    seenUrls.add(url);

    const itagMatch = url.match(/[&?]itag=(\d+)/);
    const itag = itagMatch ? itagMatch[1] : null;
    const quality = ITAG_QUALITY[itag] || 'SD';

    streams.push({ url, quality });
  }
  return streams.sort((a, b) => {
    const qA = parseInt(a.quality) || 0;
    const qB = parseInt(b.quality) || 0;
    return qB - qA;
  });
}

module.exports = { extractStreams };
