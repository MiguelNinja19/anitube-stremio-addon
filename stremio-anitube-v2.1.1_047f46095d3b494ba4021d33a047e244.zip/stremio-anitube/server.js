'use strict';

/**
 * ══════════════════════════════════════════════════════════════════
 *  Stremio Addon – AniTube.news  v2.1.1
 *  Servidor HTTP
 * ══════════════════════════════════════════════════════════════════
 */

require('dotenv').config();

const { serveHTTP } = require('stremio-addon-sdk');
const addonInterface = require('./addon');

const PORT = parseInt(process.env.PORT || '7000', 10);

try {
  serveHTTP(addonInterface, { port: PORT });
} catch (e) {
  if (e.code === 'EADDRINUSE') {
    console.error(`❌ Erro: A porta ${PORT} já está sendo usada por outro processo.`);
    console.error(`💡 Tente rodar: PORT=7001 node server.js`);
    process.exit(1);
  } else {
    console.error('❌ Erro inesperado ao iniciar servidor:', e);
    process.exit(1);
  }
}

// Banner de Boas-vindas
setTimeout(() => {
  console.log('');
  console.log('╔══════════════════════════════════════════════════╗');
  console.log('║       Stremio Addon – AniTube.news  v2.1.1       ║');
  console.log('╠══════════════════════════════════════════════════╣');
  console.log('║  ✅  Servidor rodando com sucesso!               ║');
  console.log('║                                                  ║');
  console.log(`║  📋  Para instalar no Stremio (Desktop):         ║`);
  console.log(`║      http://127.0.0.1:${PORT}/manifest.json         ║`);
  console.log('║                                                  ║');
  console.log('║  💡  Dica para o Stremio Web:                    ║');
  console.log(`║      https://web.stremio.com/#/addons?addon=     ║`);
  console.log(`║      http%3A%2F%2F127.0.0.1%3A${PORT}%2Fmanifest.json ║`);
  console.log('╚══════════════════════════════════════════════════╝');
  console.log('');
}, 500);
