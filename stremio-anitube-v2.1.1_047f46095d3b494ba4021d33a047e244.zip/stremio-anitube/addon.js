'use strict';

/**
 * ══════════════════════════════════════════════════════════════════
 *  Stremio Addon – AniTube.news  v2.0.0
 *  Servidor principal usando stremio-addon-sdk
 * ══════════════════════════════════════════════════════════════════
 *
 * COMO FUNCIONA O STREMIO ADDON SDK:
 *
 * 1. Criamos um addonBuilder com o manifesto descrevendo:
 *    - resources: quais endpoints oferecemos (catalog, meta, stream)
 *    - types: que tipos de conteúdo ('series' para animes)
 *    - catalogs: lista de catálogos que aparecem no Discover
 *    - idPrefixes: prefixo dos IDs (Stremio só nos chama para IDs que comecem com isso)
 *
 * 2. Registramos handlers para cada resource:
 *    - defineCatalogHandler → retorna { metas: [...] }
 *    - defineMetaHandler    → retorna { meta: {...} }
 *    - defineStreamHandler  → retorna { streams: [...] }
 *
 * 3. Exportamos builder.getInterface() para o server.js servir via HTTP
 */

const { addonBuilder } = require('stremio-addon-sdk');
const scraper = require('./src/scraper');
const { extractStreams } = require('./src/extractor');
const { catalogCache, metaCache, streamCache } = require('./src/cache');

// ───────────────────────────────────────────────────────────────────────────
// MANIFESTO  — a parte mais importante do addon
// ───────────────────────────────────────────────────────────────────────────
const manifest = {
  // ID único do addon — use formato reverso de domínio
  id: 'community.anitube.news',

  // Versão semântica
  version: '2.1.1',

  // Nome exibido no Stremio
  name: '🎌 AniTube.news',

  // Descrição exibida no Stremio
  description:
    'Assista animes em português (dublado e legendado) via AniTube.news. ' +
    'Inclui catálogo, meta e streams HLS diretos.',

  // Logo 256x256 (opcional mas recomendado)
  logo: 'https://www.anitube.news/wp-content/themes/newanitubevelho/img/logo.png',

  // Background 1024x786 (opcional)
  background:
    'https://www.anitube.news/wp-content/uploads/assistir-dragon-ball-super-dublado-dublado-todos-os-episodios-todos-os-episodios-online-anitube.jpg',

  // ──────────────────────────────────────────────────────────
  // resources: O QUE este addon fornece.
  //
  // "catalog" → aparece no Board/Discover; precisa de handler
  // "meta"    → detalhes do item (thumbnail, sinopse, episódios)
  //             idPrefixes: só chamado para IDs que comecem com "anitube:"
  // "stream"  → URLs de vídeo para reprodução
  //             idPrefixes: só chamado para IDs que comecem com "anitube:"
  // ──────────────────────────────────────────────────────────
  resources: [
    'catalog',
    {
      name: 'meta',
      types: ['series'],
      idPrefixes: ['anitube:'],
    },
    {
      name: 'stream',
      types: ['series'],
      idPrefixes: ['anitube:'],
    },
  ],

  // Tipos de conteúdo que este addon manipula
  types: ['series'],

  // ──────────────────────────────────────────────────────────
  // catalogs: cada entrada aparece como uma seção no Discover
  // Campos obrigatórios: id, type, name
  // extra.search: habilita busca neste catálogo
  // ──────────────────────────────────────────────────────────
  catalogs: [
    {
      id: 'anitube_ultimos_eps',
      type: 'series',
      name: '🆕 AniTube – Últimos Episódios',
      extra: [{ name: 'search', isRequired: false }],
    },
    {
      id: 'anitube_mais_vistos',
      type: 'series',
      name: '🔥 AniTube – Mais Vistos',
      extra: [{ name: 'search', isRequired: false }],
    },
    {
      id: 'anitube_recentes',
      type: 'series',
      name: '📺 AniTube – Animes Recentes',
      extra: [{ name: 'search', isRequired: false }],
    },
    {
      id: 'anitube_lista',
      type: 'series',
      name: '📚 AniTube – Lista Completa',
      extra: [
        { name: 'search', isRequired: false },
        { name: 'skip', isRequired: false },
      ],
    },
  ],

  // idPrefixes no nível do manifesto: o Stremio só enviará requisições
  // de meta/stream ao nosso addon para IDs com esse prefixo
  idPrefixes: ['anitube:'],
};

// ───────────────────────────────────────────────────────────────────────────
// Builder
// ───────────────────────────────────────────────────────────────────────────
const builder = new addonBuilder(manifest);

// Log do manifesto para debug
// console.log('Manifesto carregado:', JSON.stringify(manifest, null, 2));

// ───────────────────────────────────────────────────────────────────────────
// CATALOG HANDLER
// args.id   → id do catálogo (ex: "anitube_ultimos_eps")
// args.type → tipo (ex: "series")
// args.extra.search → string de busca (se o usuário pesquisou)
// args.extra.skip   → paginação (0, 20, 40...)
// Deve retornar: { metas: [ { id, type, name, poster }, ... ] }
// ───────────────────────────────────────────────────────────────────────────
builder.defineCatalogHandler(async (args) => {
  const { id, extra } = args;
  const search = extra && extra.search;
  const skip = (extra && extra.skip) ? parseInt(extra.skip, 10) : 0;
  const page = Math.floor(skip / 20) + 1;

  const cacheKey = `catalog:${id}:${search || ''}:${skip}`;
  const cached = catalogCache.get(cacheKey);
  if (cached) return cached;

  try {
    let metas = [];

    // Se há busca, todas as categorias respondem com resultados de busca
    if (search) {
      metas = await scraper.searchAnimes(search);
    } else {
      switch (id) {
        case 'anitube_ultimos_eps':
          metas = await scraper.getLatestEpisodes();
          break;
        case 'anitube_mais_vistos':
          metas = await scraper.getMostWatched();
          break;
        case 'anitube_recentes':
          metas = await scraper.getRecentAnimes();
          break;
        case 'anitube_lista':
          metas = await scraper.getAnimeList(page);
          break;
        default:
          metas = [];
      }
    }

    const result = { metas };
    // Cache por 5 minutos
    catalogCache.set(cacheKey, result, 5 * 60 * 1000);
    return result;
  } catch (err) {
    console.error(`[catalog] Erro em ${id}:`, err.message);
    return { metas: [] };
  }
});

// ───────────────────────────────────────────────────────────────────────────
// META HANDLER
// args.id   → ID do item (ex: "anitube:996861")
// args.type → tipo (ex: "series")
// Deve retornar: { meta: { id, type, name, poster, description, videos, ... } }
// videos: lista de episódios com { id, title, season, episode }
// ───────────────────────────────────────────────────────────────────────────
builder.defineMetaHandler(async (args) => {
  const rawId = args.id.replace('anitube:', '');

  const cacheKey = `meta:${rawId}`;
  const cached = metaCache.get(cacheKey);
  if (cached) return cached;

  try {
    const result = await scraper.getAnimeMeta(rawId);
    // Cache por 10 minutos
    metaCache.set(cacheKey, result, 10 * 60 * 1000);
    return result;
  } catch (err) {
    console.error(`[meta] Erro para ${rawId}:`, err.message);
    return { meta: null };
  }
});

// ───────────────────────────────────────────────────────────────────────────
// STREAM HANDLER
// args.id   → ID do vídeo/episódio (ex: "anitube:996993")
// args.type → tipo (ex: "series")
// Deve retornar: { streams: [ { url, name, description }, ... ] }
// ───────────────────────────────────────────────────────────────────────────
builder.defineStreamHandler(async (args) => {
  const rawId = args.id.replace('anitube:', '');

  const cacheKey = `stream:${rawId}`;
  const cached = streamCache.get(cacheKey);
  if (cached) return cached;

  try {
    // 1. Buscar os iframes disponíveis para este episódio
    const { sources, episodeUrl } = await scraper.getEpisodeIframes(rawId);

    if (!sources || sources.length === 0) {
      console.warn(`[stream] Nenhuma fonte encontrada para episódio ${rawId}`);
      return { streams: [] };
    }

    // 2. Extrair as URLs reais de vídeo (passa o episodeUrl como Referer)
    const streams = await extractStreams(sources, episodeUrl);

    const result = { streams };
    // Cache por 2 minutos (URLs de stream podem expirar)
    streamCache.set(cacheKey, result, 2 * 60 * 1000);
    return result;
  } catch (err) {
    console.error(`[stream] Erro para episódio ${rawId}:`, err.message);
    return { streams: [] };
  }
});

// ───────────────────────────────────────────────────────────────────────────
// Exportar interface para ser servida pelo server.js
// ───────────────────────────────────────────────────────────────────────────
module.exports = builder.getInterface();
