'use strict';

/**
 * Extrator de streams reais para o AniTube.news
 *
 * Baseado na análise do código Kotlin (CloudStream) e captura real de requests:
 *
 * 1. HLS DIRETO  — api.anivideo.net/videohls.php?d=<url_m3u8>
 *    → Extraímos o parâmetro "d" — é a URL .m3u8 direta
 *
 * 2. PROXY ANITUBE — anitube.news/<hash>/bg.mp4?p=1&q=<base64>
 *    → Fetch do proxy → HTML com iframe src="https://www.blogger.com/video.g?token=..."
 *    → POST batchexecute para a API do Blogger → URLs do GoogleVideo com itag
 *
 * O batchexecute usa rpcid "WcwnYd" (NÃO "B2esOe") e o endpoint correto é:
 *   https://www.blogger.com/_/BloggerVideoPlayerUi/data/batchexecute
 */

const fetch = require('node-fetch');

const UA_MOBILE =
  'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36';

const FETCH_HEADERS = {
  'User-Agent': UA_MOBILE,
  Accept: 'text/html,application/xhtml+xml,*/*;q=0.8',
  'Accept-Language': 'pt-BR,pt;q=0.9',
};

/** Mapa itag → qualidade em pixels */
const ITAG_QUALITY = {
  37: 1080,
  22: 720,
  59: 480,
  18: 360,
};

/** Mapa qualidade → rótulo amigável */
const QUALITY_LABEL = {
  1080: 'FHD 1080p',
  720: 'HD 720p',
  480: 'SD 480p',
  360: 'SD 360p',
};

/**
 * Faz fetch com timeout configurável
 */
async function safeFetch(url, opts = {}, timeout = 15000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    return await fetch(url, { ...opts, signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }
}

// ─────────────────────────────────────────────────────────────
// Tipo 1: videohls.php?d=<url_m3u8>
// ─────────────────────────────────────────────────────────────

/**
 * Extrai a URL HLS/MP4 do parâmetro "d" do iframe videohls
 * Ex: "https://api.anivideo.net/videohls.php?d=https://cdn.../index.m3u8&nocache..."
 * @param {string} src
 * @returns {string|null}
 */
function extractHLSFromVideoHLS(src) {
  try {
    const u = new URL(src);
    const d = u.searchParams.get('d');
    if (d && d.startsWith('http')) return decodeURIComponent(d);
  } catch (_) {
    // fallback: regex
    const m = src.match(/[?&]d=([^&]+)/);
    if (m) {
      try { return decodeURIComponent(m[1]); } catch (_) { return m[1]; }
    }
  }
  return null;
}

// ─────────────────────────────────────────────────────────────
// Tipo 2: Proxy AniTube → Blogger → GoogleVideo
// ─────────────────────────────────────────────────────────────

/**
 * Extrai o token do Blogger de uma URL blogger.com/video.g
 */
function extractBloggerToken(url) {
  const m = url.match(/[?&]token=([^&]+)/);
  return m ? decodeURIComponent(m[1]) : null;
}

/**
 * Decodifica múltiplos níveis de escape nas URLs do GoogleVideo
 * (A resposta do batchexecute usa \\u003d para = e \\u0026 para &)
 */
function decodeGoogleVideoUrl(raw) {
  let url = raw;
  // Descodificar \\uXXXX (múltiplos níveis)
  for (let i = 0; i < 4; i++) {
    url = url.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) =>
      String.fromCharCode(parseInt(hex, 16))
    );
    url = url.replace(/\\\//g, '/');
    url = url.replace(/\\\\/g, '\\');
    url = url.replace(/\\=/g, '=');
    url = url.replace(/\\&/g, '&');
  }
  // Remover aspas residuais
  return url.replace(/^"+|"+$/g, '').trim();
}

/**
 * Extrai o itag de uma URL GoogleVideo
 */
function extractItagFromUrl(url) {
  const m = url.match(/[?&]itag[=%](\d+)/i) || url.match(/itag=(\d+)/);
  return m ? parseInt(m[1], 10) : 18;
}

/**
 * Extrai o id do vídeo de uma URL GoogleVideo (para gerar CPN)
 */
function extractVideoId(url) {
  const m = url.match(/[?&]id=([a-f0-9]+)/);
  return m ? m[1] : 'picasacid';
}

/**
 * Gera CPN conforme a implementação Kotlin
 */
function generateCpn(token, videoId, timestamp) {
  try {
    const crypto = require('crypto');
    const bl = 'boq_bloggeruiserver_20260223.02_p0';
    const seed = `${bl}${videoId}${timestamp}${token}`;
    const hash = crypto.createHash('sha256').update(seed).digest('base64');
    return hash.replace(/[+/=]/g, '').substring(0, 16);
  } catch (_) {
    // fallback aleatório
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    return Array.from({ length: 16 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  }
}

/**
 * Extrai as URLs de vídeo da resposta bruta do batchexecute
 * Retorna array de { url, itag, quality }
 */
function parseGoogleVideoUrls(responseText) {
  const videos = [];

  // Remover prefixo ")]}'" e whitespace inicial
  const cleaned = responseText.replace(/^\)\]\}'\s*\n?/, '');

  // Extrair o JSON interno de dentro do envelope wrb.fr
  const wrbMatch = cleaned.match(
    /\[\s*\[\s*"wrb\.fr"\s*,[^,]+,\s*"([\s\S]+?)"\s*,\s*null/
  );

  let jsonStr = wrbMatch ? wrbMatch[1] : cleaned;

  // Decodificar escapes de primeiro nível
  jsonStr = jsonStr.replace(/\\"/g, '"').replace(/\\\\/g, '\\');
  jsonStr = jsonStr.replace(/\\u([0-9a-fA-F]{4})/g, (_, h) =>
    String.fromCharCode(parseInt(h, 16))
  );

  // Padrão principal (do Kotlin): "url",[[itag]]
  const urlPattern =
    /"((?:https?:(?:\\\/|\/)){2}[^"]*?googlevideo[^"]*?)",\[(\d+)\]/g;
  let m;
  while ((m = urlPattern.exec(jsonStr)) !== null) {
    const rawUrl = m[1];
    const itag = parseInt(m[2], 10);
    const decoded = decodeGoogleVideoUrl(rawUrl);
    if (decoded && decoded.includes('googlevideo.com')) {
      videos.push({ url: decoded, itag, quality: ITAG_QUALITY[itag] || 360 });
    }
  }

  // Padrão fallback: qualquer URL googlevideo sem itag ao lado
  if (videos.length === 0) {
    const fallback = /https?:[^\s"'<>]*googlevideo\.com[^\s"'<>\\]+/g;
    while ((m = fallback.exec(jsonStr)) !== null) {
      const decoded = decodeGoogleVideoUrl(m[0]);
      const itag = extractItagFromUrl(decoded);
      if (!videos.some((v) => v.itag === itag)) {
        videos.push({ url: decoded, itag, quality: ITAG_QUALITY[itag] || 360 });
      }
    }
  }

  // Remover duplicatas por itag e ordenar: melhor qualidade primeiro
  const seen = new Set();
  const unique = videos.filter((v) => {
    if (seen.has(v.itag)) return false;
    seen.add(v.itag);
    return true;
  });

  const order = [37, 22, 59, 18];
  unique.sort((a, b) => {
    const ia = order.indexOf(a.itag);
    const ib = order.indexOf(b.itag);
    return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
  });

  return unique;
}

/**
 * Chama a API batchexecute do Blogger e retorna streams GoogleVideo
 * @param {string} token
 * @param {string} referer  — URL do episódio no AniTube (para o Referer)
 * @returns {Array<{url, itag, quality}>}
 */
async function fetchBloggerStreams(token, referer) {
  // Parâmetros corretos — extraídos da captura real de rede
  const reqid = Math.floor(10000 + Math.random() * 89999);
  const fSid = '-7535563745894756252';
  const bl = 'boq_bloggeruiserver_20260317.01_p0';

  const apiUrl =
    `https://www.blogger.com/_/BloggerVideoPlayerUi/data/batchexecute` +
    `?rpcids=WcwnYd&source-path=%2Fvideo.g` +
    `&f.sid=${fSid}&bl=${bl}&hl=pt-BR&_reqid=${reqid}&rt=c`;

  // Body: f.req=[[[\"WcwnYd\",\"[\\\"<token>\\\",\\\"\\\",0]\",null,\"generic\"]]]
  const innerJson = JSON.stringify([token, '', 0]);
  const fReq = JSON.stringify([[['WcwnYd', innerJson, null, 'generic']]]);
  const body = `f.req=${encodeURIComponent(fReq)}`;

  try {
    const res = await safeFetch(apiUrl, {
      method: 'POST',
      headers: {
        'User-Agent': UA_MOBILE,
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        Accept: '*/*',
        Origin: 'https://www.blogger.com',
        Referer: 'https://www.blogger.com/',
        'sec-ch-ua': '"Chromium";v="127", "Not)A;Brand";v="99"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'x-same-domain': '1',
        'x-client-data': 'COjuygE=',
      },
      body,
    });

    if (!res.ok) return [];
    const text = await res.text();
    return parseGoogleVideoUrls(text);
  } catch (_) {
    return [];
  }
}

/**
 * Monta o stream Stremio para URL do GoogleVideo com cpn e headers corretos
 */
function makeGoogleVideoStream(tabName, { url, itag, quality }) {
  const timestamp = Date.now();
  const videoId = extractVideoId(url);

  // Extrair o token do URL (está no parâmetro da URL do blogger que gerou essa URL)
  // Como não temos o token aqui, usamos o videoId como semente
  const cpn = generateCpn(videoId, videoId, timestamp);

  const sep = url.includes('?') ? '&' : '?';
  const finalUrl = `${url}${sep}cpn=${cpn}&c=WEB_EMBEDDED_PLAYER&cver=1.20260224.08.00`;

  const label = QUALITY_LABEL[quality] || `${quality}p`;

  return {
    url: finalUrl,
    name: `AniTube | ${tabName}`,
    description: `GoogleVideo ${label}`,
    behaviorHints: {
      notWebReady: false,
      proxyHeaders: {
        request: {
          Referer: 'https://youtube.googleapis.com/',
          'User-Agent': UA_MOBILE,
        },
      },
    },
  };
}

/**
 * Processa um iframe proxy do AniTube:
 * anitube.news/<hash>/bg.mp4?p=1&q=... → faz fetch → encontra iframe Blogger
 */
async function extractFromProxyIframe(iframeSrc, episodeReferer) {
  const streams = [];

  try {
    // O proxy pode redirecionar — seguir redirecionamentos
    const res = await safeFetch(iframeSrc, {
      headers: {
        ...FETCH_HEADERS,
        Referer: episodeReferer || 'https://www.anitube.news/',
      },
      redirect: 'follow',
    });

    if (!res.ok) return streams;
    const html = await res.text();

    // Procura pelo iframe do Blogger
    const bloggerMatch = html.match(
      /src="(https?:\/\/(?:www\.)?blogger\.com\/video\.g[^"]+)"/i
    );

    if (bloggerMatch) {
      const bloggerUrl = bloggerMatch[1].replace(/&amp;/g, '&');
      const token = extractBloggerToken(bloggerUrl);
      if (token) {
        const googleVideos = await fetchBloggerStreams(token, episodeReferer);
        for (const vid of googleVideos) {
          streams.push(makeGoogleVideoStream('Player 1', vid));
        }
      }
      return streams;
    }

    // Fallback: procurar m3u8 direto no HTML
    const m3u8Match = html.match(/https?:\/\/[^\s"'<>]+\.m3u8[^\s"'<>]*/i);
    if (m3u8Match) {
      streams.push({
        url: m3u8Match[0],
        name: 'AniTube | Player 1',
        description: 'HLS Stream',
        behaviorHints: { notWebReady: false },
      });
      return streams;
    }

    // Fallback: procurar mp4
    const mp4Match = html.match(/https?:\/\/[^\s"'<>]+\.mp4[^\s"'<>]*/i);
    if (mp4Match) {
      streams.push({
        url: mp4Match[0],
        name: 'AniTube | Player 1',
        description: 'MP4',
        behaviorHints: { notWebReady: false },
      });
    }
  } catch (_) {
    /* silencioso */
  }

  return streams;
}

// ─────────────────────────────────────────────────────────────
// Função principal exportada
// ─────────────────────────────────────────────────────────────

/**
 * Extrai todos os streams Stremio a partir das fontes do scraper.
 *
 * @param {Array<{name: string, iframeSrc: string}>} sources
 *   - name: nome da aba (ex: "Player FHD", "Player 1")
 *   - iframeSrc: src do iframe.metaframe
 * @param {string} episodeUrl  — URL completa do episódio no AniTube (para Referer)
 * @returns {Array} streams compatíveis com o Stremio SDK
 */
async function extractStreams(sources, episodeUrl) {
  const streams = [];
  const episodeReferer = episodeUrl || 'https://www.anitube.news/';

  for (const source of sources) {
    const { name, iframeSrc } = source;

    // ── Tipo 1: videohls.php → extração direta do parâmetro d= ──
    if (iframeSrc.includes('videohls.php') || iframeSrc.includes('anivideo.net/videohls')) {
      const hlsUrl = extractHLSFromVideoHLS(iframeSrc);
      if (hlsUrl) {
        streams.push({
          url: hlsUrl,
          name: `AniTube | ${name}`,
          description: hlsUrl.includes('.m3u8') ? 'HLS Stream' : 'MP4 Stream',
          behaviorHints: {
            notWebReady: false,
            proxyHeaders: {
              request: {
                Referer: 'https://www.anitube.news/',
                'User-Agent': UA_MOBILE,
              },
            },
          },
        });
      }
      continue;
    }

    // ── Tipo 2: proxy AniTube → Blogger ──
    if (
      iframeSrc.includes('anitube.news/') &&
      !iframeSrc.includes('videohls.php')
    ) {
      const proxyUrl = iframeSrc.startsWith('http')
        ? iframeSrc
        : `https://www.anitube.news${iframeSrc}`;

      const extracted = await extractFromProxyIframe(proxyUrl, episodeReferer);
      // Substituir o nome genérico pelo nome real da aba
      for (const s of extracted) {
        streams.push({ ...s, name: `AniTube | ${name}` });
      }
      continue;
    }

    // ── Tipo 3: iframe Blogger direto ──
    if (iframeSrc.includes('blogger.com/video.g')) {
      const token = extractBloggerToken(iframeSrc);
      if (token) {
        const googleVideos = await fetchBloggerStreams(token, episodeReferer);
        for (const vid of googleVideos) {
          const s = makeGoogleVideoStream(name, vid);
          streams.push(s);
        }
      }
      continue;
    }

    // ── Tipo 4: qualquer outro src — tentar extração genérica ──
    const extracted = await extractFromProxyIframe(iframeSrc, episodeReferer);
    for (const s of extracted) {
      streams.push({ ...s, name: `AniTube | ${name}` });
    }
  }

  return streams;
}

module.exports = {
  extractStreams,
  // Exportados para testes
  extractHLSFromVideoHLS,
  fetchBloggerStreams,
  parseGoogleVideoUrls,
};
