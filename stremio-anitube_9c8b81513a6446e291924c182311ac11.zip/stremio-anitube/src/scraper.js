'use strict';

/**
 * Scraper para AniTube.news
 * Baseado na inspeção real do HTML do site:
 *
 * Home:
 *   - Últimos Episódios: div.epiContainer → div.epiItem
 *   - Mais Vistos:       div.aniContainer (título "Animes Mais Vistos") → .splide__slide:not(.clone) .aniItem
 *   - Recentes:          div.aniContainer (título "ANIMES RECENTES")    → .splide__slide:not(.clone) .aniItem
 *   - Lançamentos do Dia: div.aniContainer (título "LANÇAMENTOS DO DIA") → .aniItem
 *
 * URLs dos aniItems:
 *   - Formato longo:  /video/{id}/     → id extraído normalmente
 *   - Formato curto:  /{id}b[xxx]      → id = número antes do "b"
 *
 * Página de anime (/video/{id}/):
 *   - Capa:      #capaAnime img
 *   - Título:    h1 (primeiro)
 *   - Infos:     .boxAnimeSobre .boxAnimeSobreLinha
 *   - Sinopse:   #sinopse2
 *   - Episódios: .pagAniListaContainer > a
 *
 * Página de episódio:
 *   - Abas: div.pagEpiAbasItem[aba-target] → nome da aba
 *   - Containers: div#<aba-target> → iframe.metaframe[src]
 */

const fetch = require('node-fetch');
const cheerio = require('cheerio');

const BASE_URL = 'https://www.anitube.news';

const UA =
  'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36';

const FETCH_HEADERS = {
  'User-Agent': UA,
  Accept: 'text/html,application/xhtml+xml,*/*;q=0.8',
  'Accept-Language': 'pt-BR,pt;q=0.9',
  Referer: BASE_URL + '/',
};

/**
 * Faz fetch de uma URL com timeout
 */
async function fetchHTML(url, timeout = 15000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, { headers: FETCH_HEADERS, signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status} para ${url}`);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Extrai ID numérico de qualquer formato de URL do AniTube:
 *   - /video/996861/  → "996861"
 *   - /897019b002     → "897019"
 *   - /889415b        → "889415"
 */
function extractId(url) {
  if (!url) return null;
  // Formato longo: /video/{id}/
  let m = url.match(/\/video\/(\d+)\/?/);
  if (m) return m[1];
  // Formato curto: /{id}b[sufixo]  (ex: /897019b002 ou /889415b)
  m = url.match(/\/(\d{4,})b/);
  if (m) return m[1];
  return null;
}

/**
 * Remove sufixos de título: "– Todos os Episódios", "– Episódio 001", etc.
 */
function cleanTitle(raw) {
  if (!raw) return '';
  return raw
    .replace(/\s*[–\-]\s*Todos os Epis.+$/i, '')
    .replace(/\s*[–\-]\s*Epis[oó]dio\s*\d+.*$/i, '')
    .replace(/\s*[–\-]\s*Epis[oó]dios.*$/i, '')
    .replace(/&#8211;/g, '–')
    .replace(/&amp;/g, '&')
    .trim();
}

/**
 * Extrai número de episódio de um título
 */
function extractEpisodeNumber(title) {
  const patterns = [
    /Epis[oó]dio\s*(\d+)/i,
    /Ep\.?\s*(\d+)/i,
    /\bE(\d+)\b/i,
    /\b(\d{3,})\b/,
    /\b(\d{1,2})\b/,
  ];
  for (const p of patterns) {
    const m = title.match(p);
    if (m) return parseInt(m[1], 10);
  }
  return null;
}

/**
 * Cria meta preview para catálogo do Stremio
 */
function makeMetaPreview(id, name, poster) {
  return {
    id: `anitube:${id}`,
    type: 'series',
    name: cleanTitle(name),
    poster: poster || '',
    posterShape: 'poster',
  };
}

/**
 * Parseia itens aniItem de um seletor dado
 */
function parseAniItems($, selector) {
  const results = [];
  const seen = new Set();

  $(selector).each((_, el) => {
    const $a = $(el).find('a').first();
    const href = $a.attr('href') || '';
    const id = extractId(href);
    if (!id || seen.has(id)) return;
    seen.add(id);

    const name =
      $a.attr('title') ||
      $(el).find('.aniItemNome').first().text().trim() ||
      '';
    const poster =
      $(el).find('img').first().attr('src') ||
      $(el).find('img').first().attr('data-src') || '';

    if (!name) return;
    results.push(makeMetaPreview(id, name, poster));
  });

  return results;
}

/**
 * Parseia itens epiItem (episódios) da home
 * Para o Stremio usamos o ID do episódio como entrada, mas o nome
 * é limpo removendo o número do episódio (para exibir o nome do anime)
 */
function parseEpiItems($) {
  const results = [];
  const seen = new Set();

  $('div.epiItem').each((_, el) => {
    const $a = $(el).find('a').first();
    const href = $a.attr('href') || '';
    const id = extractId(href);
    if (!id || seen.has(id)) return;
    seen.add(id);

    const rawName =
      $a.attr('title') ||
      $(el).find('.epiItemNome').first().text().trim() ||
      '';

    const poster =
      $(el).find('img').first().attr('src') ||
      $(el).find('img').first().attr('data-src') || '';

    if (!rawName) return;

    results.push({
      id: `anitube:${id}`,
      type: 'series',
      // Para episódios mantemos o nome completo (incluindo "Episódio X")
      // pois o Stremio exibe isso na lista de "Últimos Episódios"
      name: rawName.trim(),
      poster,
      posterShape: 'poster',
    });
  });

  return results;
}

// ─────────────────────────────────────────────────────────────────────────────
// Catálogos Públicos
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Home — Últimos Episódios (div.epiContainer > div.epiItem)
 */
async function getLatestEpisodes() {
  const html = await fetchHTML(BASE_URL + '/');
  const $ = cheerio.load(html);
  return parseEpiItems($);
}

/**
 * Home — Animes Mais Vistos
 * Título do container: "ANITUBE ● ほとんど見た - Assistir os Animes Mais Vistos"
 * Fallback: primeiro .aniContainer ou #splide01
 */
async function getMostWatched() {
  const html = await fetchHTML(BASE_URL + '/');
  const $ = cheerio.load(html);

  // O Splide é renderizado via JS; o HTML estático tem o aniContainer com .aniItem direto
  // Procurar pelo primeiro aniContainer ("Mais Vistos")
  let targetContainer = null;
  $('.aniContainer').each((_, container) => {
    if (targetContainer) return;
    const title = $(container).find('.aniContainerTitulo').first().text();
    if (title.toLowerCase().includes('mais vistos') || title.includes('ほとんど見た')) {
      targetContainer = container;
    }
  });

  if (targetContainer) {
    const items = parseAniItems($, $(targetContainer).find('.aniItem'));
    if (items.length > 0) return items;
  }

  // Fallback: primeiro aniContainer
  return parseAniItems($, '.aniContainer:first-child .aniItem');
}

/**
 * Home — Animes Recentes
 * Título do container: "ANIMES RECENTES ● 最近のアニメ"
 * Fallback: #splide02
 */
async function getRecentAnimes() {
  const html = await fetchHTML(BASE_URL + '/');
  const $ = cheerio.load(html);

  let targetContainer = null;
  $('.aniContainer').each((_, container) => {
    if (targetContainer) return;
    const title = $(container).find('.aniContainerTitulo').first().text();
    if (title.toLowerCase().includes('recentes') || title.includes('最近')) {
      targetContainer = container;
    }
  });

  if (targetContainer) {
    const items = parseAniItems($, $(targetContainer).find('.aniItem'));
    if (items.length > 0) return items;
  }

  // Fallback: segundo aniContainer
  const containers = $('.aniContainer').toArray();
  if (containers.length >= 2) {
    return parseAniItems($, $(containers[1]).find('.aniItem'));
  }
  return [];
}

/**
 * Lista completa de animes — paginada
 */
async function getAnimeList(page = 1) {
  const url =
    page === 1
      ? `${BASE_URL}/lista-de-animes-online/`
      : `${BASE_URL}/lista-de-animes-online/page/${page}/`;
  const html = await fetchHTML(url);
  const $ = cheerio.load(html);
  return parseAniItems($, 'div.aniItem');
}

/**
 * Busca de animes por nome
 */
async function searchAnimes(query) {
  const url = `${BASE_URL}/?s=${encodeURIComponent(query)}`;
  const html = await fetchHTML(url);
  const $ = cheerio.load(html);

  // Tentar aniItems primeiro (animes)
  const aniResults = parseAniItems($, 'div.aniItem');
  if (aniResults.length > 0) return aniResults;

  // Fallback: epiItems (episódios)
  return parseEpiItems($);
}

// ─────────────────────────────────────────────────────────────────────────────
// Meta de um Anime
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Busca metadados completos de um anime
 * @param {string} animeId  — ID numérico do AniTube
 */
async function getAnimeMeta(animeId) {
  const url = `${BASE_URL}/video/${animeId}/`;
  const html = await fetchHTML(url);
  const $ = cheerio.load(html);

  // Título — o Kotlin usa h1
  const rawTitle =
    $('h1').first().text().trim() ||
    $('title').first().text().split('–')[0].trim();
  const title = cleanTitle(rawTitle);

  // Poster
  const poster =
    $('#capaAnime img').first().attr('src') ||
    $('meta[property="og:image"]').attr('content') || '';

  // Sinopse
  const description =
    $('#sinopse2').text().trim() ||
    $('meta[name="description"]').attr('content') || '';

  // Infos
  const genres = [];
  let year = '';
  let director = '';
  let cast = '';

  $('.boxAnimeSobre .boxAnimeSobreLinha').each((_, el) => {
    const text = $(el).text().trim();
    if (text.startsWith('Gênero:')) {
      genres.push(
        ...text
          .replace('Gênero:', '')
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean)
      );
    } else if (text.startsWith('Ano:')) {
      year = text.replace('Ano:', '').trim();
    } else if (text.startsWith('Diretor:')) {
      director = text.replace('Diretor:', '').trim();
    } else if (text.startsWith('Autor:')) {
      cast = text.replace('Autor:', '').trim();
    }
  });

  // Episódios: .pagAniListaContainer > a  (conforme Kotlin: EPISODE_LIST)
  const videos = [];
  $('.pagAniListaContainer a').each((i, el) => {
    const href = $(el).attr('href') || '';
    const epId = extractId(href);
    if (!epId) return;

    const epTitle =
      $(el).attr('title') || $(el).text().trim() || `Episódio ${i + 1}`;
    const epNum =
      extractEpisodeNumber(epTitle) ||
      (epTitle.match(/\b(\d+)\b/) ? parseInt(epTitle.match(/\b(\d+)\b/)[1], 10) : i + 1);

    videos.push({
      id: `anitube:${epId}`,
      title: `Episódio ${epNum}`,
      season: 1,
      episode: epNum,
      released: new Date(0).toISOString(),
    });
  });

  // Se a página for de um episódio solto (sem lista), criar episódio único
  if (videos.length === 0 && url.includes('/video/')) {
    const epNum = extractEpisodeNumber(rawTitle) || 1;
    videos.push({
      id: `anitube:${animeId}`,
      title: `Episódio ${epNum}`,
      season: 1,
      episode: epNum,
      released: new Date(0).toISOString(),
    });
  }

  // Ordenar episódios por número
  videos.sort((a, b) => a.episode - b.episode);

  return {
    meta: {
      id: `anitube:${animeId}`,
      type: 'series',
      name: title,
      poster,
      posterShape: 'poster',
      background: $('meta[property="og:image"]').attr('content') || poster,
      description,
      genres,
      year: year || undefined,
      director: director ? [director] : undefined,
      cast: cast ? [cast] : undefined,
      website: url,
      videos,
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Streams de um Episódio
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Busca as fontes de iframe na página do episódio
 * Conforme o Kotlin: pagEpiAbasItem[aba-target] + div#<target> > iframe.metaframe
 *
 * @param {string} epId  — ID numérico do episódio
 * @returns {Array<{name, iframeSrc, containerId}>}
 */
async function getEpisodeIframes(epId) {
  const url = `${BASE_URL}/video/${epId}/`;
  const html = await fetchHTML(url);
  const $ = cheerio.load(html);

  const sources = [];

  $('div.pagEpiAbasItem').each((_, aba) => {
    const tabName = $(aba).text().trim() || 'Player';
    const tabTarget = $(aba).attr('aba-target');
    if (!tabTarget) return;

    const container = $(`div#${tabTarget}`);
    if (!container.length) return;

    const iframeSrc = container.find('iframe.metaframe').first().attr('src');
    if (!iframeSrc) return;

    sources.push({
      name: tabName,
      iframeSrc,
      containerId: tabTarget,
    });
  });

  return { sources, episodeUrl: url };
}

module.exports = {
  getLatestEpisodes,
  getMostWatched,
  getRecentAnimes,
  getAnimeList,
  searchAnimes,
  getAnimeMeta,
  getEpisodeIframes,
  extractId,
  cleanTitle,
  fetchHTML,
  BASE_URL,
};
