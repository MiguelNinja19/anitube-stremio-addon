'use strict';

/**
 * ══════════════════════════════════════════════════════════════════
 *  Stremio Addon – AniTube.news  v2.0.0
 *  Servidor HTTP
 * ══════════════════════════════════════════════════════════════════
 *
 * O serveHTTP do SDK cria um servidor Express que responde em:
 *   GET /manifest.json
 *   GET /catalog/:type/:id.json
 *   GET /catalog/:type/:id/:extra.json
 *   GET /meta/:type/:id.json
 *   GET /stream/:type/:id.json
 *
 * CORS é tratado automaticamente pelo SDK.
 */

require('dotenv').config();

const { serveHTTP } = require('stremio-addon-sdk');
const addonInterface = require('./addon');

const PORT = parseInt(process.env.PORT || '7000', 10);

serveHTTP(addonInterface, { port: PORT });

// Aguardar um tick para o SDK imprimir seus logs,
// depois exibir o banner personalizado
setTimeout(() => {
  console.log('');
  console.log('╔══════════════════════════════════════════════════╗');
  console.log('║       Stremio Addon – AniTube.news  v2.0.0       ║');
  console.log('╠══════════════════════════════════════════════════╣');
  console.log('║  ✅  Servidor rodando em:                        ║');
  console.log(`║      http://127.0.0.1:${PORT}                       ║`);
  console.log('║                                                  ║');
  console.log('║  📋  Para instalar no Stremio, cole:             ║');
  console.log(`║      http://127.0.0.1:${PORT}/manifest.json         ║`);
  console.log('║                                                  ║');
  console.log('║  🌐  Testador online (Stremio Web):              ║');
  console.log(`║      https://web.stremio.com/#/addons            ║`);
  console.log('╚══════════════════════════════════════════════════╝');
  console.log('');
}, 500);
