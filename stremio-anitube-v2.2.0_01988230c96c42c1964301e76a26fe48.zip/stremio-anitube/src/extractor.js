'use strict';

const fetch = require('node-fetch');

const UA_MOBILE = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36';

const ITAG_QUALITY = {
  '18': '360p',
  '22': '720p',
  '37': '1080p',
};

const QUALITY_LABEL = {
  '360p': 'SD 360p',
  '720p': 'HD 720p',
  '1080p': 'FHD 1080p',
};

async function safeFetch(url, options = {}, timeout = 10000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, { ...options, signal: ctrl.signal });
    return res;
  } catch (e) {
    console.error(`[Extractor] Erro fetch ${url}: ${e.message}`);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/** Extrai a URL do m3u8 de um iframe videohls.php */
function extractHLSFromVideoHLS(iframeSrc) {
  if (!iframeSrc.includes('videohls.php')) return null;
  try {
    const urlObj = new URL(iframeSrc);
    const d = urlObj.searchParams.get('d');
    if (d) return decodeURIComponent(d);
  } catch (e) {
    return null;
  }
  return null;
}

async function extractStreams(sources, episodeUrl) {
  const streams = [];

  for (const source of sources) {
    const { name, iframeSrc } = source;

    // 1. Caso HLS (FHD)
    const hlsUrl = extractHLSFromVideoHLS(iframeSrc);
    if (hlsUrl) {
      streams.push({
        name: `🎌 AniTube | ${name}`,
        description: `[FHD] HLS Stream (Alta Qualidade)`,
        url: hlsUrl,
        behaviorHints: {
          notWebReady: true, // Força abrir no player externo se necessário
          proxyHeaders: {
            request: {
              'User-Agent': UA_MOBILE,
              'Referer': 'https://www.anitube.news/',
              'Origin': 'https://www.anitube.news'
            }
          }
        }
      });
      continue;
    }

    // 2. Caso Proxy Iframe (Blogger / GoogleVideo)
    if (iframeSrc.includes('anitube.news/nU') || iframeSrc.includes('api.anivideo.net')) {
      const gvStreams = await extractFromProxyIframe(iframeSrc, episodeUrl);
      if (gvStreams && gvStreams.length > 0) {
        gvStreams.forEach(s => {
          streams.push({
            name: `🎌 AniTube | ${name}`,
            description: `[${s.quality}] GoogleVideo`,
            url: s.url,
            behaviorHints: {
              proxyHeaders: {
                request: { 'User-Agent': UA_MOBILE }
              }
            }
          });
        });
      }
    }
  }

  return streams;
}

async function extractFromProxyIframe(iframeSrc, referer) {
  const res = await safeFetch(iframeSrc, {
    headers: { 'User-Agent': UA_MOBILE, 'Referer': referer }
  });
  if (!res) return [];
  const html = await res.text();

  // Se for redirecionamento para Blogger
  const bloggerMatch = html.match(/src=["'](https:\/\/www\.blogger\.com\/video\.g\?token=[^"']+)["']/);
  if (bloggerMatch) {
    return await fetchBloggerStreams(bloggerMatch[1], iframeSrc);
  }
  return [];
}

async function fetchBloggerStreams(bloggerUrl, referer) {
  const token = bloggerUrl.split('token=')[1];
  if (!token) return [];

  // Usando a captura real que funcionou no teste
  const body = `f.req=%5B%5B%5B%22WcwnYd%22%2C%22%5B%5C%22${token}%5C%22%5D%22%2Cnull%2C%22generic%22%5D%5D%5D&`;
  const res = await safeFetch('https://www.blogger.com/_/BloggerVideoPlayerUi/data/batchexecute?rpcids=WcwnYd&bl=boq_bloggeruiserver_20260317.01_p0', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'User-Agent': UA_MOBILE,
      'Referer': bloggerUrl,
      'X-Same-Domain': '1'
    },
    body
  });

  if (!res) return [];
  const text = await res.text();
  return parseGoogleVideoUrls(text);
}

function parseGoogleVideoUrls(text) {
  const streams = [];
  const matches = text.matchAll(/https:\\\/\\\/[^\s]+?googlevideo\.com\\\/videoplayback[^\s]+?(?=\\")/g);
  const seenUrls = new Set();

  for (const m of matches) {
    let url = m[0].replace(/\\u003d/g, '=').replace(/\\u0026/g, '&').replace(/\\/g, '');
    if (seenUrls.has(url)) continue;
    seenUrls.add(url);

    const itagMatch = url.match(/[&?]itag=(\d+)/);
    const itag = itagMatch ? itagMatch[1] : null;
    const quality = ITAG_QUALITY[itag] || 'SD';

    streams.push({ url, quality });
  }
  return streams.sort((a, b) => parseInt(b.quality) - parseInt(a.quality));
}

module.exports = { extractStreams };
