'use strict';

const { addonBuilder } = require('stremio-addon-sdk');
const scraper = require('./src/scraper');
const { extractStreams } = require('./src/extractor');

const manifest = {
  id: 'community.anitube.news',
  version: '2.2.0',
  name: '🎌 AniTube.news',
  description: 'Addon de anime brasileiro com suporte a HLS FHD e Google Video. Integrado com AniTube.news.',
  logo: 'https://www.anitube.news/wp-content/uploads/logo-anitube-2.png',
  background: 'https://www.anitube.news/wp-content/themes/anitube/img/bg.jpg',
  resources: ['catalog', 'meta', 'stream'],
  types: ['series', 'movie', 'anime'],
  idPrefixes: ['anitube:'],
  catalogs: [
    {
      id: 'anitube_ultimos_eps',
      type: 'series',
      name: '🆕 AniTube – Últimos Episódios',
    },
    {
      id: 'anitube_mais_vistos',
      type: 'series',
      name: '🔥 AniTube – Mais Vistos',
    },
    {
      id: 'anitube_recentes',
      type: 'series',
      name: '📺 AniTube – Animes Recentes',
    },
    {
      id: 'anitube_generos',
      type: 'series',
      name: '📚 AniTube – Gêneros',
      extra: [
        { name: 'genre', isRequired: false, options: Object.keys(scraper.GENRES_MAP) },
        { name: 'skip', isRequired: false },
        { name: 'search', isRequired: false }
      ]
    },
    {
      id: 'anitube_lista',
      type: 'series',
      name: '📚 AniTube – Lista Completa',
      extra: [{ name: 'skip', isRequired: false }]
    },
  ],
};

const builder = new addonBuilder(manifest);

// ───────────────────────────────────────────────────────────────────────────
// CATALOG HANDLER
// ───────────────────────────────────────────────────────────────────────────
builder.defineCatalogHandler(async ({ id, extra }) => {
  console.log(`[Catalog] Request: ${id} | Extra:`, JSON.stringify(extra));

  const page = Math.floor((extra.skip || 0) / 20) + 1;

  try {
    // 1. Busca
    if (extra.search) {
      const results = await scraper.searchAnimes(extra.search, page);
      return { metas: results };
    }

    // 2. Catálogos específicos
    switch (id) {
      case 'anitube_ultimos_eps':
        return { metas: await scraper.getLatestEpisodes() };
      
      case 'anitube_mais_vistos':
        return { metas: await scraper.getMostWatched() };
      
      case 'anitube_recentes':
        return { metas: await scraper.getRecentAnimes() };
      
      case 'anitube_generos':
        if (extra.genre) {
          const results = await scraper.getAnimesByGenre(extra.genre, page);
          return { metas: results };
        }
        // Se não tiver gênero, retorna lista geral
        return { metas: await scraper.getAnimeList(page) };

      case 'anitube_lista':
      default:
        return { metas: await scraper.getAnimeList(page) };
    }
  } catch (e) {
    console.error(`[Catalog] Erro: ${e.message}`);
    return { metas: [] };
  }
});

// ───────────────────────────────────────────────────────────────────────────
// META HANDLER
// ───────────────────────────────────────────────────────────────────────────
builder.defineMetaHandler(async ({ id }) => {
  const animeId = id.replace('anitube:', '');
  console.log(`[Meta] Request: ${id} (id: ${animeId})`);

  try {
    return await scraper.getAnimeMeta(animeId);
  } catch (e) {
    console.error(`[Meta] Erro: ${e.message}`);
    return { meta: {} };
  }
});

// ───────────────────────────────────────────────────────────────────────────
// STREAM HANDLER
// ───────────────────────────────────────────────────────────────────────────
builder.defineStreamHandler(async ({ id }) => {
  const epId = id.replace('anitube:', '');
  console.log(`[Stream] Request: ${id} (id: ${epId})`);

  try {
    const { sources, episodeUrl } = await scraper.getEpisodeIframes(epId);
    if (!sources || sources.length === 0) return { streams: [] };

    const streams = await extractStreams(sources, episodeUrl);
    return { streams };
  } catch (e) {
    console.error(`[Stream] Erro: ${e.message}`);
    return { streams: [] };
  }
});

module.exports = builder.getInterface();
